package com.twins.soft;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SplashActivity extends Activity {
    private final Handler handler = new Handler();
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,7,11));
        getWindow().setNavigationBarColor(Color.rgb(5,7,11));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(32,32,32,32);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(3,7,14), Color.rgb(5,18,35), Color.rgb(2,5,10)});
        root.setBackground(bg);
        ImageView icon = new ImageView(this);
        icon.setImageResource(com.twins.soft.R.drawable.twins_icon);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(220,220);
        root.addView(icon, ip);
        TextView title = new TextView(this);
        title.setText("TWINS SOFT"); title.setTextColor(Color.WHITE); title.setTextSize(30); title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1); title.setPadding(0,20,0,10);
        root.addView(title, new LinearLayout.LayoutParams(-1,-2));
        TextView sub = new TextView(this);
        sub.setText("هدية مقدمة من TWINS لصيانة وبرمجة الإلكترونيات");
        sub.setTextColor(Color.rgb(150,210,255)); sub.setTextSize(15); sub.setGravity(Gravity.CENTER); sub.setPadding(20,0,20,0);
        root.addView(sub, new LinearLayout.LayoutParams(-1,-2));
        setContentView(root);
        handler.postDelayed(() -> { startActivity(new Intent(this, MainActivity.class)); finish(); }, 1400);
    }
}
