package com.twins.soft;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.os.StatFs;
import android.os.Vibrator;
import android.os.VibrationEffect;
import android.os.BatteryManager;
import android.view.*;
import android.widget.Toast;
import java.io.File;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends Activity {
    PremiumView view;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(0,3,10));
        getWindow().setNavigationBarColor(Color.rgb(0,3,10));
        showSplash();
    }

    void showSplash() {
        SplashView splash = new SplashView(this);
        setContentView(splash);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            view = new PremiumView(this);
            setContentView(view);
        }, 3600);
    }

    void chooseFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, 77);
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (r == 77 && c == RESULT_OK && d != null && d.getData() != null) {
            Uri u = d.getData();
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); } catch (Exception ignored) {}
            Toast.makeText(this, "تم اختيار المجلد — الفحص سيبقى آمنًا", Toast.LENGTH_SHORT).show();
        }
    }

    long folderSize(File f) {
        if (f == null || !f.exists()) return 0;
        if (f.isFile()) return f.length();
        long s = 0; File[] fs = f.listFiles();
        if (fs != null) for (File x : fs) { s += folderSize(x); if (s > 512L * 1024 * 1024) break; }
        return s;
    }

    String size(long n) {
        if (n < 1024) return n + " B";
        if (n < 1024 * 1024) return String.format(Locale.US, "%.0f KB", n / 1024.0);
        if (n < 1024L * 1024 * 1024) return String.format(Locale.US, "%.1f MB", n / (1024.0 * 1024));
        return String.format(Locale.US, "%.2f GB", n / (1024.0 * 1024 * 1024));
    }

    String freeStorage() {
        try {
            StatFs st = new StatFs(getFilesDir().getAbsolutePath());
            long free = st.getAvailableBytes();
            return size(free);
        } catch (Exception e) { return "غير متاح"; }
    }

    String batteryLevel() {
        try {
            BatteryManager bm = (BatteryManager)getSystemService(BATTERY_SERVICE);
            int level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            return level >= 0 ? level + "%" : "غير متاح";
        } catch (Exception e) { return "غير متاح"; }
    }

    void vibrateLight() {
        try {
            Vibrator v = (Vibrator)getSystemService(VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE));
        } catch (Exception ignored) {}
    }

    void scan() {
        vibrateLight();
        view.startScan();
        new Thread(() -> {
            long total = folderSize(getCacheDir());
            File ext = getExternalCacheDir(); if (ext != null) total += folderSize(ext);
            // The visual scan is intentionally a little longer so the user can see the interaction.
            SystemClock.sleep(2200);
            runOnUiThread(() -> view.finishScan(total));
        }).start();
    }

    void clean() {
        new AlertDialog.Builder(this)
            .setTitle("تنظيف TWINS الآمن")
            .setMessage("سيتم تنظيف ذاكرة التخزين المؤقت الخاصة بالتطبيق فقط. لن نلمس الصور أو الفيديوهات أو المستندات أو ملفاتك الشخصية.")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("تنظيف الآن", (d, w) -> {
                vibrateLight();
                deleteChildren(getCacheDir());
                File e = getExternalCacheDir(); if (e != null) deleteChildren(e);
                view.junkBytes = 0; view.scanned = true; view.cleanFlash = 1f; view.invalidate();
                Toast.makeText(this, "تم التنظيف الآمن بنجاح ✨", Toast.LENGTH_SHORT).show();
            }).show();
    }

    void deleteChildren(File dir) {
        if (dir == null) return;
        File[] fs = dir.listFiles(); if (fs == null) return;
        for (File f : fs) deleteRec(f);
    }

    void deleteRec(File f) {
        if (f.isDirectory()) { File[] x = f.listFiles(); if (x != null) for (File c : x) deleteRec(c); }
        try { f.delete(); } catch (Exception ignored) {}
    }


    class SplashView extends View {
        Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap logo;
        float t = 0f;
        Runnable anim = new Runnable() { public void run() { t += 0.055f; invalidate(); postDelayed(this, 32); } };

        SplashView(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            logo = BitmapFactory.decodeResource(getResources(), R.drawable.app_icon);
            post(anim);
        }

        void txt(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
            sp.setStyle(Paint.Style.FILL); sp.setShader(null); sp.setColor(color); sp.setAlpha(255);
            sp.setTextSize(size); sp.setTextAlign(Paint.Align.CENTER);
            sp.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
            c.drawText(s, x, y, sp);
        }

        @Override protected void onDraw(Canvas c) {
            float w=getWidth(), h=getHeight();
            c.drawColor(Color.BLACK);
            LinearGradient g = new LinearGradient(0,0,w,h,Color.rgb(0,18,48),Color.rgb(0,2,10),Shader.TileMode.CLAMP);
            sp.setShader(g); c.drawRect(0,0,w,h,sp); sp.setShader(null);

            float cx=w/2f, cy=h*0.34f;
            float pulse=(float)Math.sin(t)*5f;
            sp.setStyle(Paint.Style.STROKE); sp.setStrokeWidth(4); sp.setColor(Color.rgb(0,180,255));
            sp.setShadowLayer(28,0,0,Color.rgb(0,100,255)); c.drawCircle(cx,cy,128+pulse,sp); sp.clearShadowLayer();
            sp.setStrokeWidth(2); sp.setColor(Color.rgb(75,230,255)); c.drawCircle(cx,cy,111+pulse*.5f,sp);

            if (logo != null) {
                RectF dst=new RectF(cx-96,cy-96,cx+96,cy+96);
                sp.setStyle(Paint.Style.FILL); sp.setAlpha(255); c.drawBitmap(logo,null,dst,sp);
            }

            txt(c,"TWINS SOFT",cx,cy+158,29,Color.WHITE,true);
            txt(c,"هدية مقدمة من TWINS",cx,cy+203,19,Color.rgb(95,220,255),true);
            txt(c,"لصيانة وبرمجة الإلكترونيات",cx,cy+233,15,Color.rgb(205,225,240),false);
            txt(c,"تنظيف ذكي • حماية آمنة • أداء أفضل",cx,cy+282,12,Color.rgb(115,155,185),false);

            float a=(float)((Math.sin(t*1.5)+1)/2);
            sp.setStrokeWidth(3); sp.setStrokeCap(Paint.Cap.ROUND); sp.setColor(Color.rgb(0,180,255));
            c.drawLine(w*.28f,h*.78f,w*(.28f+.44f*a),h*.78f,sp);
            sp.setStrokeCap(Paint.Cap.BUTT);
            txt(c,"جاري تشغيل التجربة الفاخرة...",cx,h*.83f,11,Color.rgb(75,150,190),false);
        }
    }

    class PremiumView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        RectF r = new RectF();
        Random random = new Random(7);
        boolean scanning = false, scanned = false;
        long junkBytes = 0;
        float progress = 0f, pulse = 0f, cleanFlash = 0f;
        long started;
        Runnable ticker = new Runnable() { public void run() { pulse += 0.045f; if (scanning) { progress = Math.min(.96f, progress + .012f); } if (cleanFlash > 0) cleanFlash -= .035f; invalidate(); postDelayed(this, 32); } };

        PremiumView(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            post(ticker);
        }

        void fill(Canvas c, int color) { p.setStyle(Paint.Style.FILL); p.setColor(color); p.setShader(null); }
        void round(Canvas c, float l, float t, float rr, float bb, float rad, int color) { fill(c, color); r.set(l,t,rr,bb); c.drawRoundRect(r,rad,rad,p); }
        void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align a, boolean bold) {
            fill(c,color); p.setTextSize(size); p.setTextAlign(a); p.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL)); c.drawText(s,x,y,p);
        }
        void glowCircle(Canvas c, float x, float y, float rad, int color, float alpha) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(color); p.setAlpha((int)(alpha*255)); p.setShadowLayer(18,0,0,color); c.drawCircle(x,y,rad,p); p.clearShadowLayer(); p.setAlpha(255);
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); float w=getWidth(), h=getHeight();
            c.drawColor(Color.rgb(2,7,18));
            LinearGradient bg = new LinearGradient(0,0,w,h,Color.rgb(5,18,42),Color.rgb(2,7,18),Shader.TileMode.CLAMP);
            p.setShader(bg); c.drawRect(0,0,w,h,p); p.setShader(null);

            // Ambient neon light
            fill(c, Color.rgb(0,40,90)); p.setAlpha(45); c.drawCircle(w*.15f, h*.08f, 150, p); c.drawCircle(w*.88f,h*.26f,130,p); p.setAlpha(255);

            text(c,"TWINS",w/2,48,27,Color.WHITE,Paint.Align.CENTER,true);
            text(c,"SOFT",w/2,73,14,Color.rgb(74,185,255),Paint.Align.CENTER,true);
            text(c,"تنظيف ذكي • حماية آمنة • أداء أفضل",w/2,98,12,Color.rgb(170,195,220),Paint.Align.CENTER,false);

            float cx=w/2, cy=214;
            float breathe=(float)Math.sin(pulse)*4;
            glowCircle(c,cx,cy,96+breathe,Color.rgb(0,150,255),0.48f);
            glowCircle(c,cx,cy,82+breathe*.5f,Color.rgb(0,230,255),0.72f);
            fill(c,Color.rgb(6,18,35)); c.drawCircle(cx,cy,68,p);
            // shield
            Path sh=new Path(); sh.moveTo(cx,cy-40); sh.lineTo(cx+34,cy-22); sh.lineTo(cx+29,cy+25); sh.quadTo(cx,cy+54,cx-29,cy+25); sh.lineTo(cx-34,cy-22); sh.close();
            fill(c,Color.rgb(10,42,72)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.5f); p.setColor(Color.rgb(55,205,255)); p.setShadowLayer(12,0,0,Color.rgb(0,150,255)); c.drawPath(sh,p); p.clearShadowLayer();
            text(c, scanning ? "فحص..." : (scanned ? "آمن" : "جاهز"),cx,cy+7,20,Color.WHITE,Paint.Align.CENTER,true);
            text(c, scanning ? "يبحث عن المخلفات الآمنة" : (scanned ? "الهاتف تم فحصه" : "ابدأ الفحص الذكي"),cx,cy+31,11,Color.rgb(145,185,215),Paint.Align.CENTER,false);

            // Scan progress ring
            if (scanning) {
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setStrokeCap(Paint.Cap.ROUND); p.setColor(Color.rgb(0,205,255));
                r.set(cx-103,cy-103,cx+103,cy+103); c.drawArc(r,-90,progress*360,false,p); p.setStrokeCap(Paint.Cap.BUTT);
                text(c,((int)(progress*100))+"%",cx,cy+57,11,Color.rgb(80,220,255),Paint.Align.CENTER,true);
            }

            float top=322;
            round(c,24,top,w-24,top+68,22,Color.rgb(8,30,52));
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f); p.setColor(Color.rgb(0,150,255)); r.set(24,top,w-24,top+68); c.drawRoundRect(r,22,22,p);
            text(c, scanning ? "جاري تحليل المخلفات..." : (scanned ? "إعادة الفحص" : "ابدأ فحص الهاتف"),w/2,top+30,17,Color.WHITE,Paint.Align.CENTER,true);
            text(c, scanning ? "نحمي ملفاتك الشخصية ولا نحذفها" : "اضغط لبدء تجربة التنظيف الفاخرة",w/2,top+50,10,Color.rgb(120,175,210),Paint.Align.CENTER,false);

            float y=420, gap=12, cw=(w-48-gap)/2;
            card(c,24,y,cw,"المخلفات الآمنة",scanned?size(junkBytes):"جاهز","Cache التطبيق فقط");
            card(c,24+cw+gap,y,cw,"التخزين المتاح",freeStorage(),"المساحة الحرة الآن");
            card(c,24,y+108,cw,"البطارية",batteryLevel(),"مستوى البطارية الحالي");
            card(c,24+cw+gap,y+108,cw,"الوضع الآمن","ON","صورك وملفاتك محمية");

            // Action row
            round(c,24,h-130,w-24,h-72,18,Color.rgb(7,17,30));
            text(c,"تنظيف المخلفات المكتشفة",w*.33f,h-96,13,Color.WHITE,Paint.Align.CENTER,true);
            text(c,scanned?size(junkBytes):"بعد الفحص",w*.33f,h-78,10,Color.rgb(70,200,255),Paint.Align.CENTER,false);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(Color.rgb(25,100,150)); r.set(24,h-130,w-24,h-72); c.drawRoundRect(r,18,18,p);
            text(c,"تنظيف",w*.78f,h-94,14,Color.rgb(90,220,255),Paint.Align.CENTER,true);
            text(c,"آمن",w*.78f,h-78,10,Color.rgb(130,170,200),Paint.Align.CENTER,false);
            text(c,"TWINS SOFT  •  PREMIUM 1.0",w/2,h-30,10,Color.rgb(75,105,130),Paint.Align.CENTER,false);

            if (cleanFlash > 0) { fill(c,Color.rgb(0,190,255)); p.setAlpha((int)(cleanFlash*45)); c.drawCircle(cx,cy,150*cleanFlash+80,p); p.setAlpha(255); }
        }

        void card(Canvas c,float x,float y,float cw,String title,String value,String sub) {
            round(c,x,y,x+cw,y+88,18,Color.rgb(5,16,29));
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(Color.rgb(18,65,92)); r.set(x,y,x+cw,y+88); c.drawRoundRect(r,18,18,p);
            text(c,title,x+14,y+24,11,Color.rgb(130,170,195),Paint.Align.LEFT,true);
            text(c,value,x+14,y+53,16,Color.WHITE,Paint.Align.LEFT,true);
            text(c,sub,x+14,y+73,9,Color.rgb(85,125,150),Paint.Align.LEFT,false);
        }

        void startScan() { if (scanning) return; scanning=true; scanned=false; progress=0; invalidate(); }
        void finishScan(long bytes) { scanning=false; scanned=true; progress=1; junkBytes=bytes; invalidate(); Toast.makeText(MainActivity.this,"اكتمل الفحص الذكي — لا ملفات شخصية تم لمسها",Toast.LENGTH_SHORT).show(); }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction()!=MotionEvent.ACTION_UP) return true;
            float y=e.getY(), w=getWidth(), h=getHeight();
            if (y>=315 && y<=405) { if(!scanning) scan(); return true; }
            if (y>=h-140 && y<=h-60) { if(scanned && junkBytes>0) clean(); else chooseFolder(); return true; }
            return true;
        }
    }
}
