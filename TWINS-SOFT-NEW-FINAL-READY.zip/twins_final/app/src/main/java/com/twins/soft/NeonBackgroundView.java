package com.twins.soft;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import android.widget.FrameLayout;
import java.util.Random;

public class NeonBackgroundView extends FrameLayout {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float[] xs = new float[28], ys = new float[28], speed = new float[28];
    private final Random r = new Random(7);
    public NeonBackgroundView(Context c) {
        super(c); p.setStyle(Paint.Style.FILL);
        for (int i=0;i<xs.length;i++){ xs[i]=r.nextFloat(); ys[i]=r.nextFloat(); speed[i]=0.0005f+r.nextFloat()*0.0015f; }
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c); c.drawColor(Color.rgb(5,7,11));
        for(int i=0;i<xs.length;i++){
            ys[i]-=speed[i]; if(ys[i]<0) ys[i]=1;
            p.setColor(Color.argb(80,30,150,255)); p.setShadowLayer(8,0,0,Color.rgb(0,130,255));
            c.drawCircle(xs[i]*getWidth(),ys[i]*getHeight(),2.2f,p); p.clearShadowLayer();
        }
        postInvalidateDelayed(40);
    }
}
