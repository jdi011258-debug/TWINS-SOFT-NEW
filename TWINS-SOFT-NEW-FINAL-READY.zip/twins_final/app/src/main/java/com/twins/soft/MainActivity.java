package com.twins.soft;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Build;
import android.os.StatFs;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ImageView;
import java.io.File;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView percent, status, junk, storage, battery, protection;
    private ProgressBar progress;
    private Button scan, clean;
    private Handler h = new Handler();
    private long lastCacheBytes = 0;

    int white=Color.rgb(244,248,255), muted=Color.rgb(154,169,189), blue=Color.rgb(21,151,255), cyan=Color.rgb(56,217,255), panel=Color.rgb(11,16,25);

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(5,7,11)); getWindow().setNavigationBarColor(Color.rgb(5,7,11));
        NeonBackgroundView bg=new NeonBackgroundView(this); setContentView(bg);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,18,18,24);
        bg.addView(root,new android.widget.FrameLayout.LayoutParams(-1,-1));
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); scroll.addView(content);

        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL); head.setPadding(4,4,4,10);
        ImageView icon=new ImageView(this); icon.setImageResource(R.drawable.twins_icon); icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE); head.addView(icon,new LinearLayout.LayoutParams(64,64));
        TextView ht=txt("TWINS SOFT",24,white); ht.setTypeface(null,Typeface.BOLD); ht.setPadding(12,0,0,0); head.addView(ht,new LinearLayout.LayoutParams(0,70,1)); content.addView(head);
        TextView tagline=txt("تنظيف آمن • حماية • أداء أفضل",14,cyan); tagline.setPadding(76,0,0,18); content.addView(tagline);

        LinearLayout shield=card(); ImageView si=new ImageView(this); si.setImageResource(R.drawable.twins_icon); shield.addView(si,new LinearLayout.LayoutParams(90,90));
        LinearLayout st=new LinearLayout(this); st.setOrientation(LinearLayout.VERTICAL); st.setPadding(12,0,0,0); TextView s1=txt("حماية ملفاتك الشخصية",18,white); s1.setTypeface(null,Typeface.BOLD); st.addView(s1); protection=txt("مفعّلة — الصور والفيديوهات والمستندات خارج التنظيف",12,muted); st.addView(protection); shield.addView(st,new LinearLayout.LayoutParams(0,-2,1)); content.addView(shield);

        LinearLayout stats=new LinearLayout(this); stats.setPadding(0,12,0,12);
        storage=stat("التخزين الحر","جاري الحساب"); battery=stat("البطارية","جاري الحساب");
        stats.addView(storage.getParent()==null?storage:storage,new LinearLayout.LayoutParams(0,100,1));
        // rebuild two stat cards
        stats.removeAllViews(); stats.addView(statCard("التخزين الحر",storage),new LinearLayout.LayoutParams(0,100,1)); stats.addView(space(10),new LinearLayout.LayoutParams(10,1)); stats.addView(statCard("البطارية",battery),new LinearLayout.LayoutParams(0,100,1)); content.addView(stats);

        LinearLayout scanCard=card(); TextView title=txt("فحص الهاتف",18,white); title.setTypeface(null,Typeface.BOLD); scanCard.addView(title);
        status=txt("اضغط بدء الفحص للبحث عن المخلفات الآمنة",13,muted); status.setPadding(0,6,0,12); scanCard.addView(status);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setMax(100); progress.setProgress(0); scanCard.addView(progress,new LinearLayout.LayoutParams(-1,12));
        percent=txt("0%",30,cyan); percent.setGravity(Gravity.CENTER); percent.setTypeface(null,Typeface.BOLD); scanCard.addView(percent,new LinearLayout.LayoutParams(-1,55));
        junk=txt("الكاش المكتشف: 0 B",15,white); junk.setGravity(Gravity.CENTER); scanCard.addView(junk);
        content.addView(scanCard);

        scan=new Button(this); scan.setText("بدء الفحص الذكي"); scan.setTextColor(Color.WHITE); scan.setTextSize(16); scan.setAllCaps(false); scan.setBackground(round(blue)); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,58); bp.setMargins(0,14,0,8); content.addView(scan,bp);
        clean=new Button(this); clean.setText("تنظيف آمن"); clean.setTextColor(Color.WHITE); clean.setTextSize(16); clean.setAllCaps(false); clean.setEnabled(false); clean.setBackground(round(Color.rgb(25,60,90))); content.addView(clean,new LinearLayout.LayoutParams(-1,58));

        TextView note=txt("ملاحظة: Android يمنع التطبيقات العادية من حذف كاش التطبيقات الأخرى أو ذاكرة النظام المحمية. لذلك TWINS SOFT ينظف فقط ما يملك صلاحية تنظيفه بأمان، ولا يحذف صورك أو فيديوهاتك أو مستنداتك.",12,muted); note.setPadding(6,18,6,8); content.addView(note);

        scan.setOnClickListener(v -> startScan()); clean.setOnClickListener(v -> cleanCache());
        updateStats();
    }

    private TextView txt(String s,float size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); return t; }
    private LinearLayout card(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); l.setPadding(16,14,16,14); l.setBackground(round(panel)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,5,0,5); l.setLayoutParams(p); return l; }
    private View space(int w){ View v=new View(this); return v; }
    private TextView stat(String label,String value){ TextView t=txt(value,18,white); t.setGravity(Gravity.CENTER); return t; }
    private LinearLayout statCard(String label,TextView value){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setGravity(Gravity.CENTER); l.setPadding(8,8,8,8); l.setBackground(round(panel)); TextView a=txt(label,12,muted); a.setGravity(Gravity.CENTER); l.addView(a); value.setGravity(Gravity.CENTER); l.addView(value); return l; }
    private GradientDrawableCompat round(int color){ return new GradientDrawableCompat(color); }
    private static class GradientDrawableCompat extends android.graphics.drawable.GradientDrawable { GradientDrawableCompat(int c){ super(); setColor(c); setCornerRadius(22); setStroke(1,Color.argb(100,40,160,255)); } }

    private void startScan(){ vibrate(); scan.setEnabled(false); clean.setEnabled(false); progress.setProgress(0); percent.setText("0%"); status.setText("جاري فحص الكاش والملفات المؤقتة الآمنة…");
        final long bytes=calculateCacheBytes(); lastCacheBytes=bytes;
        for(int i=1;i<=100;i++){ final int x=i; h.postDelayed(() -> { progress.setProgress(x); percent.setText(x+"%"); if(x<35) status.setText("فحص الكاش…"); else if(x<70) status.setText("تحليل الملفات المؤقتة…"); else if(x<100) status.setText("تجهيز نتيجة التنظيف الآمن…"); else { status.setText("اكتمل الفحص بأمان"); junk.setText("الكاش المكتشف: "+format(bytes)); clean.setEnabled(bytes>0); scan.setEnabled(true); vibrate(); } }, i*24L); }
    }
    private void cleanCache(){ vibrate(); long before=calculateCacheBytes(); deleteContents(getCacheDir()); long after=calculateCacheBytes(); long cleaned=Math.max(0,before-after); lastCacheBytes=after; junk.setText("تم تنظيف: "+format(cleaned)); status.setText("تم التنظيف الآمن — ملفاتك الشخصية لم تُمس"); clean.setEnabled(after>0); updateStats(); }
    private long calculateCacheBytes(){ return folderSize(getCacheDir()); }
    private long folderSize(File f){ if(f==null||!f.exists()) return 0; if(f.isFile()) return f.length(); File[] a=f.listFiles(); if(a==null) return 0; long s=0; for(File x:a) s+=folderSize(x); return s; }
    private void deleteContents(File f){ File[] a=f.listFiles(); if(a==null)return; for(File x:a){ if(x.isDirectory()) { deleteContents(x); x.delete(); } else x.delete(); } }
    private void updateStats(){ StatFs s=new StatFs(getFilesDir().getAbsolutePath()); long free=s.getAvailableBytes(); storage.setText(format(free)); BatteryManager bm=(BatteryManager)getSystemService(BATTERY_SERVICE); int b=bm!=null?bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY):-1; battery.setText(b>=0?b+"%":"غير متاح"); }
    private String format(long n){ if(n<1024) return n+" B"; double k=n/1024.0; if(k<1024)return String.format(Locale.US,"%.1f KB",k); double m=k/1024.0; if(m<1024)return String.format(Locale.US,"%.1f MB",m); return String.format(Locale.US,"%.2f GB",m/1024.0); }
    private void vibrate(){ Vibrator v=(Vibrator)getSystemService(Context.VIBRATOR_SERVICE); if(v==null)return; if(Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createOneShot(35,VibrationEffect.DEFAULT_AMPLITUDE)); else v.vibrate(35); }
}
